module.exports = {
  name: "CRUSH PICCHI RAJ",
  timezone: "Asia/Dhaka",
  language: "bn"
};
