// প্রতি ঘণ্টার কাজ এখানে যোগ করা যাবে।
function hourlyTask() {
  console.log("Hourly task:", new Date().toISOString());
}
module.exports = { hourlyTask };
