require("dotenv").config();
const express = require("express");
const app = express();
app.use(express.json());

app.get("/", (_req,res)=>res.send("RAJ EXPERT BOT ONLINE ❤️"));
app.get("/webhook",(req,res)=>{
  if(req.query["hub.verify_token"]===process.env.VERIFY_TOKEN)
    return res.status(200).send(req.query["hub.challenge"]);
  res.sendStatus(403);
});
app.post("/webhook",(_req,res)=>res.sendStatus(200));

app.listen(process.env.PORT||3000,()=>console.log("RAJ EXPERT BOT started"));
