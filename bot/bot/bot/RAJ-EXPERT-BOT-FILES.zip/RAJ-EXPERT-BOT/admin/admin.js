module.exports = {
  isAdmin: (senderId, adminIds=[]) => adminIds.includes(senderId)
};
