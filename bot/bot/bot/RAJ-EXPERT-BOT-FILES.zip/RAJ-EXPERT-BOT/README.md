# RAJ EXPERT BOT 🤖❤️

Command-per-file Messenger bot project.

Folders:
- commands/ = one JS file per command
- config/ = bot settings
- data/ = reply/data files
- database/ = future user data
- media/ = approved media links
- scheduler/ = scheduled tasks
- admin/ = admin tools
- utils/ = helper functions

Add your own Messenger webhook logic and credentials in `.env`.
Never upload `.env` or access tokens.
