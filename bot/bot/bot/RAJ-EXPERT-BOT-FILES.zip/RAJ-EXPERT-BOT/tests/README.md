Command tests go here.
