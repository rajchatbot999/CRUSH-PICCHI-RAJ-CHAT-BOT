module.exports = {
  welcome: "আসসালামু আলাইকুম ❤️ আমি CRUSH PICCHI RAJ BOT 🤖",
  unknown: "এই কমান্ডটা এখনো যোগ করা হয়নি। `help` লিখে মেনু দেখো।",
  romantic: "তোমার মেসেজটা পড়ে হাসি চলে এলো 😊❤️"
};
