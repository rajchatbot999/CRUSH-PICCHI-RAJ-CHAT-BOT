module.exports = {
  name: "menu",
  description: "মূল মেনু দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "menu",
      message: "মূল মেনু দেখাবে।"
    };
  }
};
