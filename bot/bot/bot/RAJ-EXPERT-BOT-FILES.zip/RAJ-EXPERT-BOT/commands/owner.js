module.exports = {
  name: "owner",
  description: "বট মালিকের তথ্য দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "owner",
      message: "বট মালিকের তথ্য দেখাবে।"
    };
  }
};
