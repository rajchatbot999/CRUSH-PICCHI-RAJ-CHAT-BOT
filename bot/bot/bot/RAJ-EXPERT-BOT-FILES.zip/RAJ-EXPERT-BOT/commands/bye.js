module.exports = {
  name: "bye",
  description: "বিদায় রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "bye",
      message: "বিদায় রিপ্লাই।"
    };
  }
};
