module.exports = {
  name: "thanks",
  description: "ধন্যবাদ রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "thanks",
      message: "ধন্যবাদ রিপ্লাই।"
    };
  }
};
