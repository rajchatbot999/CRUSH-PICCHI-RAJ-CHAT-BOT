module.exports = {
  name: "dua",
  description: "দোয়ার মেনু।",
  async execute(ctx) {
    return {
      ok: true,
      command: "dua",
      message: "দোয়ার মেনু।"
    };
  }
};
