module.exports = {
  name: "date",
  description: "আজকের তারিখ দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "date",
      message: "আজকের তারিখ দেখাবে।"
    };
  }
};
