module.exports = {
  name: "unban",
  description: "অ্যাডমিন moderation placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "unban",
      message: "অ্যাডমিন moderation placeholder।"
    };
  }
};
