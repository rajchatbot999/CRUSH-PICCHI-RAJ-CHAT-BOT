module.exports = {
  name: "video",
  description: "ভিডিও মেনু।",
  async execute(ctx) {
    return {
      ok: true,
      command: "video",
      message: "ভিডিও মেনু।"
    };
  }
};
