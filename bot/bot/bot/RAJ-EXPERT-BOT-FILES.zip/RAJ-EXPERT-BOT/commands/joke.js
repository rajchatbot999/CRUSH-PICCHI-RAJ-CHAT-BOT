module.exports = {
  name: "joke",
  description: "মজার জোকস।",
  async execute(ctx) {
    return {
      ok: true,
      command: "joke",
      message: "মজার জোকস।"
    };
  }
};
