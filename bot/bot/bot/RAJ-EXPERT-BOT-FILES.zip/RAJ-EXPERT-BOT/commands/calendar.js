module.exports = {
  name: "calendar",
  description: "ক্যালেন্ডার ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "calendar",
      message: "ক্যালেন্ডার ফিচারের placeholder।"
    };
  }
};
