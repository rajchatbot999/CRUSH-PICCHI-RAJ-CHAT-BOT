module.exports = {
  name: "islamic",
  description: "ইসলামিক তথ্যের মেনু।",
  async execute(ctx) {
    return {
      ok: true,
      command: "islamic",
      message: "ইসলামিক তথ্যের মেনু।"
    };
  }
};
