module.exports = {
  name: "coinflip",
  description: "Coin flip।",
  async execute(ctx) {
    return {
      ok: true,
      command: "coinflip",
      message: "Coin flip।"
    };
  }
};
