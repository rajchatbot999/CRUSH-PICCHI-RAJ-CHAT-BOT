module.exports = {
  name: "quiz",
  description: "কুইজ।",
  async execute(ctx) {
    return {
      ok: true,
      command: "quiz",
      message: "কুইজ।"
    };
  }
};
