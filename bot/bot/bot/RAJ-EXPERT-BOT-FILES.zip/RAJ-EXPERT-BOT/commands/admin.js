module.exports = {
  name: "admin",
  description: "অ্যাডমিন মেনুর placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "admin",
      message: "অ্যাডমিন মেনুর placeholder।"
    };
  }
};
