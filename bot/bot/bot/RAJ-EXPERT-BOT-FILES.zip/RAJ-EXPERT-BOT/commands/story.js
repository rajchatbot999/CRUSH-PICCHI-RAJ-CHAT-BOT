module.exports = {
  name: "story",
  description: "ছোট গল্প।",
  async execute(ctx) {
    return {
      ok: true,
      command: "story",
      message: "ছোট গল্প।"
    };
  }
};
