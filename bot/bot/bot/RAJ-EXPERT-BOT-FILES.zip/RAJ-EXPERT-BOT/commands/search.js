module.exports = {
  name: "search",
  description: "সার্চ ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "search",
      message: "সার্চ ফিচারের placeholder।"
    };
  }
};
