module.exports = {
  name: "translatebn",
  description: "বাংলা অনুবাদ placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "translatebn",
      message: "বাংলা অনুবাদ placeholder।"
    };
  }
};
