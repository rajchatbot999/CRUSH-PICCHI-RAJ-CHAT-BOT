module.exports = {
  name: "translate",
  description: "অনুবাদ ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "translate",
      message: "অনুবাদ ফিচারের placeholder।"
    };
  }
};
