module.exports = {
  name: "uptime",
  description: "বট uptime দেখানোর placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "uptime",
      message: "বট uptime দেখানোর placeholder।"
    };
  }
};
