module.exports = {
  name: "time",
  description: "ঢাকার বর্তমান সময় দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "time",
      message: "ঢাকার বর্তমান সময় দেখাবে।"
    };
  }
};
