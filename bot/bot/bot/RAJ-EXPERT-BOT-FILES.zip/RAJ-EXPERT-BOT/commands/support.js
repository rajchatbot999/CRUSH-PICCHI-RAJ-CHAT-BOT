module.exports = {
  name: "support",
  description: "সাপোর্ট মেনু।",
  async execute(ctx) {
    return {
      ok: true,
      command: "support",
      message: "সাপোর্ট মেনু।"
    };
  }
};
