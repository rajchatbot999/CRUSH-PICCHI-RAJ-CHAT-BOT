module.exports = {
  name: "roll",
  description: "Dice roll।",
  async execute(ctx) {
    return {
      ok: true,
      command: "roll",
      message: "Dice roll।"
    };
  }
};
