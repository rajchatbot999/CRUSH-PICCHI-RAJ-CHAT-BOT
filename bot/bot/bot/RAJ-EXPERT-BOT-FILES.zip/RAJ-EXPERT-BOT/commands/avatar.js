module.exports = {
  name: "avatar",
  description: "অ্যাভাটার ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "avatar",
      message: "অ্যাভাটার ফিচারের placeholder।"
    };
  }
};
