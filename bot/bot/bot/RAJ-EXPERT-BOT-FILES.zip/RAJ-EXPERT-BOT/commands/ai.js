module.exports = {
  name: "ai",
  description: "AI রিপ্লাই ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "ai",
      message: "AI রিপ্লাই ফিচারের placeholder।"
    };
  }
};
