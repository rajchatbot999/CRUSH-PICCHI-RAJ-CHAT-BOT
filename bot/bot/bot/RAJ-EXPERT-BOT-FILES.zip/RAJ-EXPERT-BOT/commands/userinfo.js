module.exports = {
  name: "userinfo",
  description: "ইউজার তথ্যের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "userinfo",
      message: "ইউজার তথ্যের placeholder।"
    };
  }
};
