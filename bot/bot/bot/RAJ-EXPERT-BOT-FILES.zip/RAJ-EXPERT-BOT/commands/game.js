module.exports = {
  name: "game",
  description: "গেম মেনু।",
  async execute(ctx) {
    return {
      ok: true,
      command: "game",
      message: "গেম মেনু।"
    };
  }
};
