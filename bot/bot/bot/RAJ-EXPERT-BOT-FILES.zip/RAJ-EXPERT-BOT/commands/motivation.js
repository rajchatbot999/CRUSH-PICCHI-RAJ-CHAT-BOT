module.exports = {
  name: "motivation",
  description: "মোটিভেশনাল রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "motivation",
      message: "মোটিভেশনাল রিপ্লাই।"
    };
  }
};
