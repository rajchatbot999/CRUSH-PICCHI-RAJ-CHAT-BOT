module.exports = {
  name: "quote",
  description: "ছোট অনুপ্রেরণামূলক উক্তি।",
  async execute(ctx) {
    return {
      ok: true,
      command: "quote",
      message: "ছোট অনুপ্রেরণামূলক উক্তি।"
    };
  }
};
