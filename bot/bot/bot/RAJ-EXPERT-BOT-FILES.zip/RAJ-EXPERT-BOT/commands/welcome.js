module.exports = {
  name: "welcome",
  description: "ওয়েলকাম রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "welcome",
      message: "ওয়েলকাম রিপ্লাই।"
    };
  }
};
