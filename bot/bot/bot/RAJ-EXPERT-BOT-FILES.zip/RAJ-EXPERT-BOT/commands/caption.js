module.exports = {
  name: "caption",
  description: "ক্যাপশন সাজেশন।",
  async execute(ctx) {
    return {
      ok: true,
      command: "caption",
      message: "ক্যাপশন সাজেশন।"
    };
  }
};
