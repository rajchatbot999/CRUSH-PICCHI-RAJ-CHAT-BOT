module.exports = {
  name: "help",
  description: "সাহায্য/কমান্ড মেনু দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "help",
      message: "সাহায্য/কমান্ড মেনু দেখাবে।"
    };
  }
};
