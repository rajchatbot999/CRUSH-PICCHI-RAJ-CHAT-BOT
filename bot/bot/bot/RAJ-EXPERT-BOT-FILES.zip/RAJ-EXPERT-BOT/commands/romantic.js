module.exports = {
  name: "romantic",
  description: "রোমান্টিক রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "romantic",
      message: "রোমান্টিক রিপ্লাই।"
    };
  }
};
