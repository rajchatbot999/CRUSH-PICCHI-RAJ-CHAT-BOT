module.exports = {
  name: "namaz",
  description: "ঢাকার নামাজের সময় দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "namaz",
      message: "ঢাকার নামাজের সময় দেখাবে।"
    };
  }
};
