module.exports = {
  name: "profile",
  description: "প্রোফাইল ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "profile",
      message: "প্রোফাইল ফিচারের placeholder।"
    };
  }
};
