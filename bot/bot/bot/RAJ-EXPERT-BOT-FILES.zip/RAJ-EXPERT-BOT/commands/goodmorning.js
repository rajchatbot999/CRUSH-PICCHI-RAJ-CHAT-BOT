module.exports = {
  name: "goodmorning",
  description: "সুপ্রভাত রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "goodmorning",
      message: "সুপ্রভাত রিপ্লাই।"
    };
  }
};
