module.exports = {
  name: "goodnight",
  description: "শুভরাত্রি রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "goodnight",
      message: "শুভরাত্রি রিপ্লাই।"
    };
  }
};
