module.exports = {
  name: "about",
  description: "বটের পরিচিতি দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "about",
      message: "বটের পরিচিতি দেখাবে।"
    };
  }
};
