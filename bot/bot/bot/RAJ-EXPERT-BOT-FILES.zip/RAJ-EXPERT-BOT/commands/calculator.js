module.exports = {
  name: "calculator",
  description: "ক্যালকুলেটর ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "calculator",
      message: "ক্যালকুলেটর ফিচারের placeholder।"
    };
  }
};
