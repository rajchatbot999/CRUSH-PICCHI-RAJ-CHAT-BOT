module.exports = {
  name: "song",
  description: "গান/অডিও মেনু।",
  async execute(ctx) {
    return {
      ok: true,
      command: "song",
      message: "গান/অডিও মেনু।"
    };
  }
};
