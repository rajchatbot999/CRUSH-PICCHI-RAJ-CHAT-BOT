module.exports = {
  name: "love",
  description: "সুন্দর রোমান্টিক রিপ্লাই।",
  async execute(ctx) {
    return {
      ok: true,
      command: "love",
      message: "সুন্দর রোমান্টিক রিপ্লাই।"
    };
  }
};
