module.exports = {
  name: "broadcast",
  description: "অ্যাডমিন ব্রডকাস্ট placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "broadcast",
      message: "অ্যাডমিন ব্রডকাস্ট placeholder।"
    };
  }
};
