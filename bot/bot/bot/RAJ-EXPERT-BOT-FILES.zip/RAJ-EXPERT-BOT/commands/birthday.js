module.exports = {
  name: "birthday",
  description: "জন্মদিনের শুভেচ্ছা।",
  async execute(ctx) {
    return {
      ok: true,
      command: "birthday",
      message: "জন্মদিনের শুভেচ্ছা।"
    };
  }
};
