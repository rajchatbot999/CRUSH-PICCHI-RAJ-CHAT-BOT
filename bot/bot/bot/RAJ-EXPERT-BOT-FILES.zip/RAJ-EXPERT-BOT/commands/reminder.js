module.exports = {
  name: "reminder",
  description: "রিমাইন্ডার ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "reminder",
      message: "রিমাইন্ডার ফিচারের placeholder।"
    };
  }
};
