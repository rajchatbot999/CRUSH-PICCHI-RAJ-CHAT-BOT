module.exports = {
  name: "weather",
  description: "আবহাওয়ার ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "weather",
      message: "আবহাওয়ার ফিচারের placeholder।"
    };
  }
};
