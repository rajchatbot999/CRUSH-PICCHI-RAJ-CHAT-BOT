module.exports = {
  name: "photo",
  description: "ছবি মেনু।",
  async execute(ctx) {
    return {
      ok: true,
      command: "photo",
      message: "ছবি মেনু।"
    };
  }
};
