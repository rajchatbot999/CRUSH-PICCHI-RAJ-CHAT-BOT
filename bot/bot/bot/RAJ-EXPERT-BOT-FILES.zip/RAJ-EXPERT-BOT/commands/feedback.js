module.exports = {
  name: "feedback",
  description: "ফিডব্যাক নেওয়ার placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "feedback",
      message: "ফিডব্যাক নেওয়ার placeholder।"
    };
  }
};
