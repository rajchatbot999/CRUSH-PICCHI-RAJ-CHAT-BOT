module.exports = {
  name: "rules",
  description: "বটের নিয়ম।",
  async execute(ctx) {
    return {
      ok: true,
      command: "rules",
      message: "বটের নিয়ম।"
    };
  }
};
