module.exports = {
  name: "ban",
  description: "অ্যাডমিন moderation placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "ban",
      message: "অ্যাডমিন moderation placeholder।"
    };
  }
};
