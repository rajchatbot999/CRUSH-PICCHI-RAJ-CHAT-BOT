module.exports = {
  name: "ping",
  description: "বট অনলাইন কিনা দেখাবে।",
  async execute(ctx) {
    return {
      ok: true,
      command: "ping",
      message: "বট অনলাইন কিনা দেখাবে।"
    };
  }
};
