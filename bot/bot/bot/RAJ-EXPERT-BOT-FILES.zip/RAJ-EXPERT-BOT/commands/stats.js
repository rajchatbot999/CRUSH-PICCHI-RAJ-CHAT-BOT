module.exports = {
  name: "stats",
  description: "বট স্ট্যাটস placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "stats",
      message: "বট স্ট্যাটস placeholder।"
    };
  }
};
