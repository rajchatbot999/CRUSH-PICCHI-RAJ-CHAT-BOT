module.exports = {
  name: "notify",
  description: "নোটিফিকেশন ফিচারের placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "notify",
      message: "নোটিফিকেশন ফিচারের placeholder।"
    };
  }
};
