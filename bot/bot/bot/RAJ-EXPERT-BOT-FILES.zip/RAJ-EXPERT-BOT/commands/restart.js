module.exports = {
  name: "restart",
  description: "রিস্টার্ট placeholder।",
  async execute(ctx) {
    return {
      ok: true,
      command: "restart",
      message: "রিস্টার্ট placeholder।"
    };
  }
};
