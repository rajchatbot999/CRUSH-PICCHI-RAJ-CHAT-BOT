module.exports = function command(name, description, run) {
  return { name, description, run };
};
